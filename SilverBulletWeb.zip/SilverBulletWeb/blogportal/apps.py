from django.apps import AppConfig


class BlogportalConfig(AppConfig):
    name = 'blogportal'
